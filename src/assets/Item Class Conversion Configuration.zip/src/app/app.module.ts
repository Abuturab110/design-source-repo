import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app.routing.module';
import { AppComponent } from './app.component';
import { DigitalInsightsLandingComponent } from './digital-insights-landing/digital-insights-landing.component';
import { DigitalCoreLandingComponent } from './digital-core-landing/digital-core-landing.component';
import { DigitalInnovationExploreComponent } from './digital-innovation-explore/digital-innovation-explore.component';

@NgModule({
  declarations: [
    AppComponent,
    DigitalInsightsLandingComponent,
    DigitalCoreLandingComponent,
    DigitalInnovationExploreComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
