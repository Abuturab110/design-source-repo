import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DigitalCoreLandingComponent } from './digital-core-landing.component';

describe('DigitalCoreLandingComponent', () => {
  let component: DigitalCoreLandingComponent;
  let fixture: ComponentFixture<DigitalCoreLandingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DigitalCoreLandingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DigitalCoreLandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
