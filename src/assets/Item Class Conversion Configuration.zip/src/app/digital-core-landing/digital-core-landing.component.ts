import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-digital-core-landing',
  templateUrl: './digital-core-landing.component.html',
  styleUrls: ['./digital-core-landing.component.css']
})
export class DigitalCoreLandingComponent implements OnInit {

  @Input() key: string;

  jsondata: Array<Data>;

  updatedjsondata: Array<Data>;



  constructor() { }

  ngOnInit() {

    this.key = 'Clean Core';
    this.key = 'Digitized Core';
    // this.key = 'Extended Core';


    this.jsondata =
      [

        {
          "cores": {
            "Clean Core": {
              "actions": {
                "Eliminate Data Debt": {
                  "dimensions": [
                    "PTP",
                    "OTC",
                    "RTR",
                    "PTM"
                  ]
                },
                "Eliminate Technical Debt": {
                  "dimensions": [
                    "PTP",
                    "OTC",
                    "RTR",
                    "PTM"
                  ]
                },
                "Simplify & Standardize": {
                  "dimensions": [
                    "PTP",
                    "OTC",
                    "RTR",
                    "PTM"
                  ]
                }
              }
            },
            "Digitized Core": {
              "actions": {
                "Automate Core": {
                  "dimensions": [
                    "PTP",
                    "OTC",
                    "RTR",
                    "PTM"
                  ]
                },
                "Imagine Digital": {
                  "dimensions": [
                    "PTP",
                    "OTC",
                    "RTR",
                    "PTM"
                  ]
                }
              }
            },
            "Extended Core": {
              "actions": {
                "Identify Unique Business Processes": {
                  "dimensions": [
                    "PTP",
                    "OTC",
                    "RTR",
                    "PTM"
                  ]
                },
                "Integrate with Ecosystem": {
                  "dimensions": [
                    "PTP",
                    "OTC",
                    "RTR",
                    "PTM"
                  ]
                }
              }
            }
          }
        }

      ]

  }





  public selectCore(evt, core) {
    var i, tabcontent, tablinks;
    // console.log('evt', evt);
    // console.log('core', core);
    //this.updatedjsondata = this.jsondata[0].cores["Clean Core"].actions[core].dimensions;
    this.updatedjsondata = this.jsondata[0].cores[this.key].actions[core].dimensions;


    console.log('this.jsondata', this.jsondata);
    console.log('this.updatedjsondata', this.updatedjsondata);

    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(core).style.display = "block";
    evt.currentTarget.className += " active";

  }
 
  handleClick($event) {

    // this.router.navigateByUrl("https://www.google.com");
    // window.location.href="https://www.google.com";
    window.open("https://www.google.com", "_blank");

  }



}

interface Data {
  cores: Cores;
}

interface Cores {
  "Clean Core": CleanCore;
  "Digitized Core": DigitizedCore;
  "Extended Core": ExtendedCore;
}


interface ElminateDataDebt {
  dimensions: string[];
}

interface ElminateTechnicalDebt {
  dimensions: string[];
}

interface SimplifyStandardize {
  dimensions: string[];
}

interface Actions {
  "Eliminate Data Debt": ElminateDataDebt;
  "Eliminate Technical Debt": ElminateTechnicalDebt;
  "Simplify & Standardize": SimplifyStandardize;
}

interface CleanCore {
  actions: Actions;
}

interface AutomateCore {
  dimensions: string[];
}

interface ImagineDigital {
  dimensions: string[];
}

interface Actions2 {
  "Automate Core": AutomateCore;
  "Imagine Digital": ImagineDigital;
}

interface DigitizedCore {
  actions: Actions2;
}

interface IdentifyUniqueBusinessProcesses {
  dimensions: string[];
}

interface IntegrateWithEcosystem {
  dimensions: string[];
}

interface Actions3 {
  "Identify Unique Business Processes": IdentifyUniqueBusinessProcesses;
  "Integrate with Ecosystem": IntegrateWithEcosystem;
}

interface ExtendedCore {
  actions: Actions3;
}

