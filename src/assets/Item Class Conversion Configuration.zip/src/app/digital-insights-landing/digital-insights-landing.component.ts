import { Component, Input, OnInit } from '@angular/core';
import { Router } from "@angular/router";

@Component({
  selector: 'app-digital-insights-landing',
  templateUrl: './digital-insights-landing.component.html',
  styleUrls: ['./digital-insights-landing.component.css']
})
export class DigitalInsightsLandingComponent implements OnInit {

  @Input() key: string;



  constructor(private router: Router) { }

  ngOnInit() {
    //this.key = 'Value';
    //this.key = 'Benchmark';
    this.key = 'Assessment';

  }


  handleClick($event) {

    // this.router.navigateByUrl("https://www.google.com");
    // window.location.href="https://www.google.com";
    window.open("https://www.google.com", "_blank");

  }

}
