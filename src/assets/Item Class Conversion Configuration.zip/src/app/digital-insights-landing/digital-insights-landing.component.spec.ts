import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DigitalInsightsLandingComponent } from './digital-insights-landing.component';

describe('DigitalInsightsLandingComponent', () => {
  let component: DigitalInsightsLandingComponent;
  let fixture: ComponentFixture<DigitalInsightsLandingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DigitalInsightsLandingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DigitalInsightsLandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
