import { Component, Input, OnInit } from '@angular/core';
import { Router } from "@angular/router";

@Component({
  selector: 'app-digital-innovation-explore',
  templateUrl: './digital-innovation-explore.component.html',
  styleUrls: ['./digital-innovation-explore.component.css']
})
export class DigitalInnovationExploreComponent implements OnInit {

  @Input() key: string;

  constructor(private router: Router) { }

  ngOnInit() {

    this.key = 'Digital Foundry';
    // this.key = 'Use Cases'; 
    // this.key = 'Digital Native Design'; 
    // this.key = 'Operate to Innovate'; 
  }


  handleClick($event) {

    // this.router.navigateByUrl("https://www.google.com");
    // window.location.href="https://www.google.com";
    window.open("https://www.google.com", "_blank");

  }
}
