import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DigitalInnovationExploreComponent } from './digital-innovation-explore.component';

describe('DigitalInnovationExploreComponent', () => {
  let component: DigitalInnovationExploreComponent;
  let fixture: ComponentFixture<DigitalInnovationExploreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DigitalInnovationExploreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DigitalInnovationExploreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
