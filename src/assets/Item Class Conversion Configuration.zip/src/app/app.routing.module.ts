import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DigitalInsightsLandingComponent } from './digital-insights-landing/digital-insights-landing.component';
import { DigitalCoreLandingComponent } from './digital-core-landing/digital-core-landing.component';
import { DigitalInnovationExploreComponent } from './digital-innovation-explore/digital-innovation-explore.component';


const routes: Routes = [
    { path: 'digitalinsightslanding', component: DigitalInsightsLandingComponent },
    { path: 'digitalinnovationexplore', component: DigitalInnovationExploreComponent },
    { path: 'digitalcorelanding', component: DigitalCoreLandingComponent }
];

@NgModule({
    imports: [
        RouterModule.forRoot(routes)
    ],
    exports: [
        RouterModule
    ],
    declarations: []
})
export class AppRoutingModule { }